This collection of templates is sold "as is" with no additonal support or updates included.

If you need continuus professional support, bugfixes, frequent updates & new components, 
we recommend switching to one of the actively maintaned projects listed on:
https://mdbootstrap.com/

For hosting & easy deployment options, please visit:
https://mdbgo.com/

For access & login problems, please contact:
contact@mdbootstrap.com

For enterprise & licensing enquiries, please contact:
enterprise@mdbootstrap.com

